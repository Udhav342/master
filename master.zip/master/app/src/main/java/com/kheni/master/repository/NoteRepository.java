package com.kheni.master.repository;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;

import com.kheni.master.data.Note;
import com.kheni.master.db.NoteDao;
import com.kheni.master.db.NoteDatabase;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class NoteRepository {
    private NoteDao noteDao;
    private LiveData<List<Note>> allNotes;
    private final Executor executor = Executors.newSingleThreadExecutor(); // change according to your requirements
    private final Handler handler = new Handler(Looper.getMainLooper());

    public NoteRepository(Application application) {
        NoteDatabase database = NoteDatabase.getInstance(application);
        noteDao = database.noteDao();
        allNotes = noteDao.getAllNotes();
    }

    public void insert(Note note) {
        executor.execute(() -> noteDao.insert(note));
    }

    public void update(Note note) {
        executor.execute(() -> noteDao.update(note));
    }

    public void delete(Note note) {
        executor.execute(() -> noteDao.delete(note));
    }

    public void deleteAllNotes() {
        executor.execute(() -> noteDao.deleteAllNotes());
    }

    public LiveData<List<Note>> getAllNotes() {
        return allNotes;
    }

    public Executor getExecutor() {
        return executor;
    }

    public Handler getHandler() {
        return handler;
    }
}
