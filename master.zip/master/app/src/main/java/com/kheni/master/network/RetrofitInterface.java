package com.kheni.master.network;

import com.kheni.master.model.Photos;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetrofitInterface {
        @GET("/photos")
        Call<List<Photos>> getAllPhotos(@Query("albumId") long albumId);
}
