package com.kheni.master.repository;

import android.database.Observable;

import com.kheni.master.model.Photos;
import com.kheni.master.network.RetrofitInterface;

import java.util.List;

public class ApiRepository {
    private RetrofitInterface apiCallInterface;

    public ApiRepository(RetrofitInterface apiCallInterface) {
        this.apiCallInterface = apiCallInterface;
    }

    public List<Photos> executeNewsApi(int index) {
        return (List<Photos>) apiCallInterface.getAllPhotos(index);
    }
}
